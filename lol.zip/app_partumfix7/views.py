from django.shortcuts import render,redirect
from app_partumfix7.models import Usuario
from django.urls import reverse_lazy
from .forms import FormularioUsuario

# Create your views here.

def index(request):
    form = FormularioUsuario()
    return render(request, 'app_partumfix7/index.html',{'form':form})

def catalogo(request):
    return render(request, 'catalogo.html')

def chaquetas(request):
    return render(request, 'chaquetas.html')

def vestidos(request):
    return render(request, 'vestidos.html')

def poleras(request):
    return render(request, 'poleras.html')

def nosotros(request):
    return render(request, 'nosotros.html')

def registrar_usuario(request):
    if request.method == 'POST':
        form = FormularioUsuario(request.POST)
        if form.is_valid():
            form.save()
            # Usuario.objects.create_user(
            #     nombre_usuario = form.cleaned_data.get('nombre_usuario'),
            #     nombres = form.cleaned_data.get('nombres'),
            #     apellidos = form.cleaned_data.get('apellidos'),
            #     telefono = form.cleaned_data.get('telefono'),
            #     mail = form.cleaned_data.get('mail'),
            #     direccion = form.cleaned_data.get('direccion')
            # )
            return redirect('index')
    else:
        form = FormularioUsuario()
    return render(request, 'app_partumfix7/index.html', {
        'form': form
    })