from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager

# Create your models here.
class ModeloBase(models.Model):
    id = models.AutoField(primary_key=True)
    estado = models.BooleanField('Estado producto', default=True)
    fecha_creacion = models.DateField('Fecha de creacion', auto_now_add=True)
    fecha_modificacion = models.DateField('Fecha de modificacion', auto_now=True, auto_now_add=False)
    fecha_eliminacion = models.DateField('Fecha de eliminacion', auto_now=True, auto_now_add=False)

    class Meta:
        abstract = True

class UsuarioManagerPersonalizado(BaseUserManager):
    def create_user(self, nombre_usuario, nombres, apellidos, telefono, mail, direccion, password):
        if(not mail):
            raise ValueError('el correo electronico es obligatorio')
        usuario = Usuario(
            nombre_usuario = nombre_usuario,
            nombres = nombres,
            apellidos = apellidos,
            telefono = telefono,
            mail = mail,
            direccion = direccion
        )
        usuario.set_password(password)
        usuario.save()
        return usuario

    def create_superuser(self, nombre_usuario, nombres, apellidos, telefono, mail, direccion, password):
        usuario = self.create_user(
            nombre_usuario = nombre_usuario,
            nombres = nombres,
            apellidos = apellidos,
            telefono = telefono,
            mail = mail,
            direccion = direccion,
            password = password
        )
        usuario.usuario_administrador = True
        usuario.save()
        return True

class Categoria(ModeloBase):
    titulo_categoria = models.CharField('Titulo Categoria', max_length=50)
    imagen_categoria = models.ImageField('Imagen Categoria')
    favorito_grande = models.BooleanField('Favorito grande Categoria', default=False)
    favorito = models.BooleanField('Favorito Categoria', default=False)

    class Meta:
        verbose_name = 'Categoria'
        verbose_name_plural = 'Categorias'

    def __str__(self):
        return self.titulo_categoria

class Producto(ModeloBase):
    titulo_producto = models.CharField('Titulo producto', max_length=30, unique=True)
    precio = models.IntegerField('Precio producto')
    descripcion_producto = models.TextField('Descripcion producto', null=True, blank=True)
    imagen_producto = models.ImageField('Imagen producto', null=True, blank=True)
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)

    class Meta:
        verbose_name = 'Producto'
        verbose_name_plural = 'Productos'

    def __str__(self):
        return self.titulo_producto

class Usuario(ModeloBase, AbstractBaseUser):
    nombre_usuario = models.CharField('User Name', unique = True, max_length = 30)
    nombres = models.CharField('Nombres del usuario', max_length=100)
    apellidos = models.CharField('Apellidos del usuario', max_length=100)
    telefono = models.CharField('Telefono del usuario', max_length=15)
    mail = models.EmailField('E-mail del usuario', unique=True)
    direccion = models.CharField('Direccion del usuario', max_length=200)
    usuario_administrador = models.BooleanField('admin', default = False)
    objects = UsuarioManagerPersonalizado()

    class Meta:
        verbose_name = 'Usuario'
        verbose_name_plural = 'Usuarios'

    def __str__(self):
        return f"{self.nombres} {self.apellidos}"

    USERNAME_FIELD = 'mail'
    REQUIRED_FIELDS = ['nombre_usuario', 'nombres', 'apellidos', 'telefono', 'direccion']

    class Meta:
        verbose_name = 'Usuario'
        verbose_name_plural = 'Usuarios'

    def __str__(self):
        return '{0} {1}'.format(self.nombres, self.apellidos)

    def has_perm(self, perm, obj = None):
        return True

    def has_module_perms(self, app_label):
        return True

    @property
    def is_staff(self):
        return self.usuario_administrador

class Articulo(ModeloBase):
    imagen_articulo = models.ImageField('Imagen articulo', null=True, blank=True)
    titulo_articulo = models.CharField('Titulo del articulo', max_length=50, unique=True)
    descripcion_articulo = models.CharField('Descripcion Articulo', max_length=300)
    slug = models.CharField('Slug', max_length=150, unique=True)
    publicado = models.BooleanField('Publicado', default=False)
    autor = models.ForeignKey(Usuario, on_delete=models.CASCADE)

    class Meta:
        verbose_name = 'Articulo'
        verbose_name_plural = 'Articulos'

    def __str__(self):
        return self.titulo_articulo

class DetalleVenta(ModeloBase):
    precio_total = models.IntegerField('Precio Total')
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE)

    class Meta:
        verbose_name = 'Detalle de Venta'
        verbose_name_plural = 'Detalle de Ventas'

class CarroCompra(ModeloBase):
    Producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    Usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE)

    class Meta:
        verbose_name = 'Carro de Compra'
        verbose_name_plural = 'Carro de Compras'

class Nosotros(ModeloBase):
    texto = models.TextField('Texto Nosotros', max_length=300)

    class Meta:
        verbose_name = 'Nosotros'