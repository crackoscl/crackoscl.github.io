from django import forms
from django.core import validators
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm
from django.forms import TextInput, EmailInput, PasswordInput, Textarea
User = get_user_model()

class FormularioUsuario(UserCreationForm):
    # password = forms.CharField(
    #     label = 'Contraseña Usuario',
    #     widget = forms.PasswordInput(),
    #     required = True
    # )

    class Meta:
        model = User
        # fields = ['nombre_usuario', 'nombres', 'apellidos','telefono','mail','direccion']
        fields = '__all__'
        widgets = {
            'nombre_usuario': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Nombre Usuario'}),
            'nombres': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Email'}),
            'apellidos': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Apellidos'}),
            'telefono': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Telefono'}),
            'mail': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Mail'}),
            'direccion': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Direccion'}),

        }

        def __init__(self, *args, **kwargs):
            super(FormularioUsuario, self).__init__(*args, **kwargs)
            self.fields['password1'].widget = PasswordInput(
                attrs={'class': 'form-control', 'placeholder': 'Contraseña'})
            self.fields['password2'].widget = PasswordInput(
                attrs={'class': 'form-control', 'placeholder': 'Confirmación Contraseña'})
            self.fields['email'].required = True


    # def save(self, commit = True):
    #     user = super().save(commit = False)
    #     user.set_password(self.cleaned_data['password'])
    #     if(commit):
    #         user.save()
    #     return user