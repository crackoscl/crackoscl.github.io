from django import forms
from django.core import validators
from django.contrib.auth.forms import AuthenticationForm
from app_partumfix7.models import Usuario

class FormularioUsuario(forms.ModelForm):
    password = forms.CharField(
        label = 'Contraseña Usuario',
        widget = forms.PasswordInput(),
        required = True
    )

    class Meta:
        model = Usuario
        fields = ['nombre_usuario', 'nombres', 'apellidos']
        widgets = {
            'nombre_usuario': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Nombre Usuario'}),
            'nombres': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Email'}),
            'apellidos': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Rut'}),
        }

    def save(self, commit = True):
        user = super().save(commit = False)
        user.set_password(self.cleaned_data['password'])
        if(commit):
            user.save()
        return user